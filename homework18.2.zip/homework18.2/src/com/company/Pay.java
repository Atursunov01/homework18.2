package com.company;

public interface Pay {
    void  method1();

}
